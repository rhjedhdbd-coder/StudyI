STUDYI ANDROID APP - STARTER PROJECT

Yeh ek React Native + Expo Android app starter project hai.

Isme abhi:
- Premium dark StudyI chat interface
- Camera se photo lena
- Gallery se image select karna
- PDF file select karna
- Image preview aur chat UI
- Demo responses

IMPORTANT:
Abhi yeh real AI app nahi hai. AI answers ke liye secure backend zaroori hai.
API key ko App.js ya mobile app ke andar kabhi mat daalna.
API_URL ko tabhi set karna jab secure backend deploy ho.

PHONE SE PREVIEW:
1. Expo Snack ya kisi compatible Expo development environment mein project files import karo.
2. package.json ki dependencies install honi chahiye.
3. Expo Go version aur Expo SDK compatible hone chahiye.

ANDROID BUILD:
Is project ko baad mein EAS Build se Android APK/AAB mein build kiya ja sakta hai.
Play Store publishing ke liye Google Play developer account aur testing requirements apply hoti hain.

App name: StudyI
Android package: com.studyi.learning
