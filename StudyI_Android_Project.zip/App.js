import React, { useState } from "react";
import {
  View, Text, TextInput, TouchableOpacity, ScrollView,
  StyleSheet, StatusBar, Image, KeyboardAvoidingView,
  Platform, ActivityIndicator, Alert
} from "react-native";
import * as ImagePicker from "expo-image-picker";
import * as DocumentPicker from "expo-document-picker";

const API_URL = ""; // Add your secure AI backend URL here after setup.

export default function App() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [image, setImage] = useState(null);
  const [busy, setBusy] = useState(false);

  async function chooseImage(camera = false) {
    const permission = camera
      ? await ImagePicker.requestCameraPermissionsAsync()
      : await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) {
      Alert.alert("Permission needed", "Allow camera or photo access to continue.");
      return;
    }
    const result = camera
      ? await ImagePicker.launchCameraAsync({ quality: 0.8 })
      : await ImagePicker.launchImageLibraryAsync({ mediaTypes: ["images"], quality: 0.8 });
    if (!result.canceled) setImage(result.assets[0]);
  }

  async function choosePDF() {
    const result = await DocumentPicker.getDocumentAsync({
      type: ["application/pdf"],
      copyToCacheDirectory: true
    });
    if (!result.canceled) {
      setMessages(old => [...old, {
        role: "user",
        text: "📄 Selected PDF: " + result.assets[0].name
      }]);
      Alert.alert("PDF selected", "PDF selection works. AI document analysis will be enabled when the secure AI backend is connected.");
    }
  }

  async function send() {
    if ((!input.trim() && !image) || busy) return;
    const userMsg = { role: "user", text: input.trim(), image: image?.uri };
    const next = [...messages, userMsg];
    setMessages(next);
    setInput("");
    setImage(null);
    setBusy(true);

    try {
      if (API_URL) {
        const body = new FormData();
        body.append("message", userMsg.text);
        if (image) {
          body.append("image", {
            uri: image.uri,
            name: image.fileName || "question.jpg",
            type: image.mimeType || "image/jpeg"
          });
        }
        const response = await fetch(API_URL, { method: "POST", body });
        if (!response.ok) throw new Error("AI server returned " + response.status);
        const data = await response.json();
        setMessages(old => [...old, { role: "ai", text: data.reply || "No answer returned." }]);
      } else {
        setMessages(old => [...old, {
          role: "ai",
          text: userMsg.image
            ? "Photo received successfully! 📷 The camera/gallery feature is ready. To read the board or solve the question in the photo, connect a vision-capable AI backend. This starter app is currently in demo mode."
            : "Welcome to StudyI! ✨ Your study assistant interface is ready. Connect a secure AI backend to enable real answers, explanations and step-by-step solutions."
        }]);
      }
    } catch (e) {
      setMessages(old => [...old, {
        role: "ai",
        text: "I couldn't reach the AI service. Check your connection and backend setup, then try again."
      }]);
    } finally {
      setBusy(false);
    }
  }

  return (
    <KeyboardAvoidingView style={s.root} behavior={Platform.OS === "ios" ? "padding" : undefined}>
      <StatusBar barStyle="light-content" backgroundColor="#090B14" />
      <View style={s.header}>
        <View>
          <Text style={s.brand}>✦ StudyI</Text>
          <Text style={s.tagline}>YOUR WORLD OF LEARNING</Text>
        </View>
        <View style={s.pill}><Text style={s.pillText}>● STUDY MODE</Text></View>
      </View>

      <ScrollView style={s.chat} contentContainerStyle={s.chatContent} keyboardShouldPersistTaps="handled">
        {messages.length === 0 ? (
          <View style={s.welcome}>
            <Text style={s.spark}>✦</Text>
            <Text style={s.title}>Learn Anything.</Text>
            <Text style={s.purpleTitle}>Anywhere.</Text>
            <Text style={s.subtitle}>Ask a question, upload a board photo, or explore a subject.</Text>
            {["Explain this maths problem step by step", "Teach me Japanese N3", "Explain electricity simply", "Make a science practice quiz"].map(x =>
              <TouchableOpacity key={x} style={s.suggestion} onPress={() => setInput(x)}>
                <Text style={s.suggestionText}>{x}</Text><Text style={s.arrow}>›</Text>
              </TouchableOpacity>
            )}
          </View>
        ) : messages.map((m, i) => (
          <View key={i} style={[s.message, m.role === "user" ? s.user : s.ai]}>
            <Text style={s.messageLabel}>{m.role === "user" ? "YOU" : "✦ STUDYI"}</Text>
            {!!m.image && <Image source={{ uri: m.image }} style={s.messageImage} resizeMode="contain" />}
            {!!m.text && <Text style={s.messageText}>{m.text}</Text>}
          </View>
        ))}
        {busy && <View style={s.loading}><ActivityIndicator color="#B99AFF" /><Text style={s.loadingText}>StudyI is thinking…</Text></View>}
      </ScrollView>

      <View style={s.composer}>
        {image && <View style={s.previewWrap}>
          <Image source={{ uri: image.uri }} style={s.preview} />
          <TouchableOpacity style={s.remove} onPress={() => setImage(null)}><Text style={{color:"#fff"}}>×</Text></TouchableOpacity>
        </View>}
        <View style={s.toolRow}>
          <TouchableOpacity style={s.tool} onPress={() => chooseImage(true)}><Text style={s.toolText}>📷 Camera</Text></TouchableOpacity>
          <TouchableOpacity style={s.tool} onPress={() => chooseImage(false)}><Text style={s.toolText}>🖼️ Gallery</Text></TouchableOpacity>
          <TouchableOpacity style={s.tool} onPress={choosePDF}><Text style={s.toolText}>📄 PDF</Text></TouchableOpacity>
        </View>
        <View style={s.inputRow}>
          <TextInput
            style={s.input}
            placeholder="Ask StudyI anything…"
            placeholderTextColor="#8991A8"
            value={input}
            onChangeText={setInput}
            multiline
          />
          <TouchableOpacity style={s.send} onPress={send} disabled={busy}>
            <Text style={s.sendText}>↑</Text>
          </TouchableOpacity>
        </View>
      </View>
      <Text style={s.footer}>StudyI can make mistakes. Check important answers.</Text>
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  root:{flex:1,backgroundColor:"#090B14"},
  header:{paddingTop:18,paddingBottom:16,paddingHorizontal:20,borderBottomWidth:1,borderColor:"#252B40",flexDirection:"row",justifyContent:"space-between",alignItems:"center"},
  brand:{fontSize:27,fontWeight:"800",color:"#C2A8FF"},
  tagline:{fontSize:9,letterSpacing:2,color:"#7F89A5",marginTop:4},
  pill:{backgroundColor:"#182B28",paddingHorizontal:10,paddingVertical:7,borderRadius:20},
  pillText:{color:"#77DDB0",fontSize:9,fontWeight:"700"},
  chat:{flex:1},
  chatContent:{padding:17,paddingBottom:24},
  welcome:{paddingTop:30},
  spark:{fontSize:48,color:"#B99AFF",textAlign:"center"},
  title:{fontSize:30,fontWeight:"800",color:"#FFFFFF",textAlign:"center",marginTop:8},
  purpleTitle:{fontSize:30,fontWeight:"800",color:"#A98AFF",textAlign:"center"},
  subtitle:{fontSize:14,color:"#9AA3BA",textAlign:"center",lineHeight:22,marginTop:14,marginBottom:28},
  suggestion:{backgroundColor:"#151C2E",borderColor:"#303A56",borderWidth:1,borderRadius:14,padding:16,marginBottom:10,flexDirection:"row",justifyContent:"space-between",alignItems:"center"},
  suggestionText:{color:"#E8E9F5",fontSize:13,flex:1},
  arrow:{color:"#B99AFF",fontSize:23,marginLeft:8},
  message:{padding:15,borderRadius:15,marginBottom:12,maxWidth:"94%"},
  user:{backgroundColor:"#292443",alignSelf:"flex-end"},
  ai:{backgroundColor:"#151D2E",alignSelf:"stretch"},
  messageLabel:{color:"#BCA5FF",fontSize:10,fontWeight:"800",marginBottom:8},
  messageText:{color:"#F1F2FA",fontSize:15,lineHeight:23},
  messageImage:{width:220,height:190,borderRadius:10,marginBottom:9,backgroundColor:"#222"},
  loading:{flexDirection:"row",alignItems:"center",gap:10,padding:12},
  loadingText:{color:"#BCA5FF"},
  composer:{marginHorizontal:10,marginBottom:4,padding:10,borderWidth:1,borderColor:"#414563",borderRadius:18,backgroundColor:"#151B2D"},
  toolRow:{flexDirection:"row",flexWrap:"wrap",gap:7,marginBottom:8},
  tool:{backgroundColor:"#292344",paddingVertical:8,paddingHorizontal:10,borderRadius:10},
  toolText:{color:"#D9CCFF",fontSize:12,fontWeight:"600"},
  previewWrap:{alignSelf:"flex-start",marginBottom:10,position:"relative"},
  preview:{width:82,height:82,borderRadius:10},
  remove:{position:"absolute",right:-7,top:-7,width:22,height:22,borderRadius:11,backgroundColor:"#D94C68",alignItems:"center",justifyContent:"center"},
  inputRow:{flexDirection:"row",alignItems:"center"},
  input:{flex:1,minHeight:42,maxHeight:100,color:"#fff",fontSize:15,paddingHorizontal:8,paddingVertical:9},
  send:{width:43,height:43,borderRadius:13,backgroundColor:"#8664E9",alignItems:"center",justifyContent:"center",marginLeft:7},
  sendText:{fontSize:27,color:"#fff",fontWeight:"700"},
  footer:{textAlign:"center",fontSize:10,color:"#737D96",paddingVertical:9}
});
